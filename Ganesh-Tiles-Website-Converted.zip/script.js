function sendWhatsApp() {
    let phone = "919789398717";
    let message = "Hello Ganesh Tiles,%0A%0AI am interested in your tile services.%0APlease share details and pricing.";
    let url = "https://wa.me/" + phone + "?text=" + message;
    window.open(url, "_blank");
}

document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault();
    let name = document.getElementById("name").value;
    let phone = document.getElementById("phone").value;
    let work = document.getElementById("work").value;
    let message = document.getElementById("message").value;

    let whatsappMessage =
        "Hello Ganesh Tiles,%0A%0A" +
        "Name: " + encodeURIComponent(name) + "%0A" +
        "Phone: " + encodeURIComponent(phone) + "%0A" +
        "Tile Work: " + encodeURIComponent(work) + "%0A" +
        "Requirement: " + encodeURIComponent(message);

    let whatsappURL = "https://wa.me/919789398717?text=" + whatsappMessage;
    window.open(whatsappURL, "_blank");
    document.getElementById("contactForm").reset();
});
